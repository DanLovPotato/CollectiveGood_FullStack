const express = require("express");
const router = express.Router();

const authController = require("../controllers/auth");


// controller is to deal with data
router.post('/register', authController.register);
router.post('/login', authController.login);

module.exports = router;